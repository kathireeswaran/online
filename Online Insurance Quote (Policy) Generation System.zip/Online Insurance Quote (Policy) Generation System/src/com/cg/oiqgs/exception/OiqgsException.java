package com.cg.oiqgs.exception;

@SuppressWarnings("serial")
public class OiqgsException extends Exception {

	public OiqgsException(String message) {
		super(message);
	}
}
